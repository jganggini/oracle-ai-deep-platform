## Página 1 <a id="p1"></a>

<table><tr><td colspan="2">Fecha Folio</td></tr><tr><td>22/jun/2022 18:16:22</td><td>Z3191</td></tr></table>
 [p1](#p1)

# SECRETARIA DE GOBIERNACION

BUCARELI 99   
JUAREZ   
CUAUHTEMOC , CDMX CP: 06600   
RFC: SGO8501012H2   
Domicilio fiscal: 06600   
Régimen fiscal: 603/Personas Morales con Fines no Lucrativos
 [p1](#p1)

<table><tr><td>Artículo</td><td>Nombre</td></tr><tr><td>RES</td><td>RESERVACION</td></tr><tr><td>RES</td><td>9011503/Hospedajes de cama y desayuno RESERVACION 90111503/Hospedajes de cama y desayuno</td></tr></table>
 [p1](#p1)

# Cadena original del complemento de certificación digital del SAT:

PE57pEMPH/X|Q==100010000502000436|1 Sello digital del CFDI:
 [p1](#p1)

#
 [p1](#p1)

pwg0ryX7869VnfMmosx6tjn9u/guJ7hrZkbHsU5ZI+cWKkKnz1FrIwgVxF+ai6UW3sSOysPqNykpkC9/zV+jXINsYNJKLT57oU3SCC3jWd2vV1Q $^ { + }$ HW00IHy4AS8IqbR3ADSmCeulmEA5VBuldb/Zy6vkLOm3ZrZ1bqaiM3mNC4qYMVmEU20KUH3yYJme :5/x7GWuhtYgTVahqkVC3Bz26+zgAgDFpX1mlyMeW16E7Wd4UbFQN1wf3WMAuyK5BPFbwAay2SgABaE56y3lzHEG08/CIDFTFQpqE5pEMH $= =$
 [p1](#p1)

<table><tr><td>U.med.</td><td>Unidades</td><td>Precio</td><td>Descto.</td><td>Importe</td></tr><tr><td>SERV E48/Unidad de servicio</td><td>1</td><td>357.15</td><td></td><td>357.15</td></tr><tr><td>SERV E48/Unidad de servicio</td><td>1</td><td>357.15</td><td></td><td>357.15</td></tr></table>
 [p1](#p1)

# Sello digital del SAT:

alodCO581HNkCAy+xabbRVgadyBI+7LyHabVdpWFQHd7xyZHkAFuRHHkR $^ { \star }$ 3W8/FhWubgxUKR+F0Rv13oX5Zg0qOMw2hKYhyEVmxAdzAz
 [p1](#p1)

![](images/p1_f43340f7951fb22304c555e6c5653834dc5d2d7a7d648fe6dceb46d427a3c6da.jpg)
 [p1](#p1)

<table><tr><td>□ (Ochocientos cincuenta pesos 00/100 m.n.) ne HUESPED: BARBARA PACHECO HABITACION: 14 HOSPEDAJE: 17 DE JUNIO 2022 Método de pago: PUE/Pago en una sola exhibición Forma de pago: 04/Tarjeta de crédito Uso del CFDI: G03/Gastos en general</td><td>Subtotal ISH 002|IVA16</td><td>714.30 21.42 114.28</td></tr><tr><td colspan="3">Este documento es una representación impresa de un CFDI. Folio del SAT: D1E90A30-1566-DE45-8F6C-3B63F3362312 Fecha de certificación: 2/jun/2022 18:17:23 Crtificado del emisor:0000506241642 Certificado dl SAT: 00100000500436 Régimen fiscal del emisor: 601/General de Ley Personas Morales Lugar de expedición: 26850 CFDI 4.0/Ingreso</td></tr></table>
 [p1](#p1)


## Página 2 <a id="p2"></a>

<?xml version $= " 1 . 0 "$ encoding ${ = } ^ { 1 }$ UTF- $8 " ? >$   
<cfi:Comprobante LugarExpedicion="26850" MetodoPago="PUE" Exportacion="01" TipoDeComprobante="T" Total="850.00" Moneda—"MN"SbTotal="714.0"   
Certificado"MIIGFDCCA/gAWIBAgIUMDAwMDEwMDAWMDA1MDYyNDE2NDIwDQYJKoZIhveNAQELBQAwggGEMSAwHgYDVQQDDBaBVVRPUkEC   
NoCertificado="0000100000506241642" FormaPago $e " 0 4 "$   
Sello-"Wpwg0ry4X786y9VnfMmosrxtjn9/g.J7hrZkbHs5Zi+ceWKkZKnz1FrwWwgVxF+ai6Uw3sOysPqNykpkC9/zV+jXNsYNJKLT57oU3SC3jWd2vV1(   
Fecha-"202-06-2T18:16:2"Foio"3191" Srie"Z" Version="4.0" mns:cdi"htp:/ww.satgob.m/fd/4" si:scemacation="htp:/wsatb.x/fd/4   
http:/ww.sat.gob.mx/sito_itrnet/fd/cfdv40.xsd htp:/ww.satgb.m/implocalhtt:/ww.sat.gob.mx/sitio_internet/cfd/imploca/imploca.sd"   
xmlns:implocal="htp://www.sat.gob.mx/implocal" xmlns:xsi="http:/www.w3.org/2001/XMILSchema-instance"> <cfdi:Emisor RegimenFiscal="601" Nombre="INMOBILIARIA Z'CRUZ SILLER" Rfc="IZS0711307Y4"/ <cfdi:Receptor Nombre="SECRETARIA DE GOBERNACION" Rfc="SG08501012H2" USsoCFDI="G03" RegimenFiscalReceptor="603" DomicilioFiscalReceptor= $\bf \Pi ^ { \mathrm { = " 0 6 6 0 0 " / > } }$ <cfdi:Conceptos> <cfdi:Concepto Objetolmp="02" Importe="357.15" ValorUnitario="357.15" Descripcion="RESERVACION" Unidad="SERV" ClaveUnidad="E48" Cantidad="1" Noldentificacion $\cdot = "$ RES" ClaveProdServ="90111503"> <cfdi:1mpuestos> <efdi:Traslados> <cfdi:Traslado Importe="57.1424" TasaOCuota="0.160000" TipoFactor="Tasa" Impuesto="002" Base="357.14"/> </cefdi: Traslados> </cfdi:1mpuestos> </cfdi:Concepto> <cfdi:Concepto Objetolmp="02" Importe="37.15" ValorUnitario="357.15" Descripcion="RESERVACION" Unidad="SERV" ClaveUnidad="E48" Cantidad="1" Noldentificacion $\cdot \ "$ RES" ClaveProdServ $r = "$ 90111503"> <cfdi:Impuestos> <cfdi:Traslados> <cfdi:Traslado Importe $\mathrel { \mathop : } \mathbf { - }$ 57.1424" TasaOCuota $= "$ 0.160000" TipoFactor="Tasa" Impuesto="002" Base="357.14"/> </cfdi:Traslados> </cfdi:Impuestos> </cfdi:Concepto> </cfdi:Conceptos> <efdi:Impuestos TotalImpuestosTrasladados $= " 1 1 4 . 2 8 " >$ <cfdi:Traslados> <cfdi:Traslado Importe $\approx ^ { 1 }$ '114.28" TasaOCuota $= "$ 0.160000" TipoFactor="Tasa" Impuesto $\mathbf { \Lambda } ^ { \sharp } \mathbf { 0 0 2 ^ { \prime \prime } }$ Base="714.28"/> </cfdi:Traslados> </cfdi:Impuestos> <cfdi:Complemento> <implocal:ImpuestosLocales TotaldeTraslados $\mathbf { \lambda } _ { \mathrm { s } } = " 2 1 . 4 2 "$ TotaldeRetenciones $\mathbf { \mu } ^ { = " } \mathbf { 0 . 0 0 " }$ version $= " 1 . 0 " >$ <implocal: TrasladosLocales Importe $= ^ { 1 1 } 2 1 . 4 2 "$ Tasade Traslado $_ { 1 } = " 3 . 0 0 "$ ImpLoc Trasladad $\scriptstyle \mathbf { \mu } = " \mathbf { I s H " } / >$ </implocal:ImpuestosLocales> <tfd:TimbreFiscalDigital Version $= " 1 . 1 "$ xsi:schemaLocation="htp://www.sat.gob.mx/TimbreFiscalDigital http://www.sat.gob.mx/sitio_ internet/efd/TimbreFiscalDigital/TimbreFiscalDigitalv11.xsd" UUID $| = ^ { n }$ D1E90A30-1566-DE45-8F6C-3B63F3362312" FechaTimbrado="2022-06-22T18:17:23" RfcProvCertif="SCD110105654" SelloCFD="Wpwg0ry4X786v9VnfMmosrx6tjJn9u/guJ7hrZk6HsU5Zi+cWKkZKnz1Frw1wgVxF+ai6Uw3sOysPqNykpkC9/zV+jXINsYNJKLT57ol NoCertificadoSAT="0001000000502000436" SelloSAT $| = "$ NzalodCOy581oZPHaN3k4CA6y+xabbh52RVggaoSVdyBqI+7LWUMy8BHPo3rHdsabdMAE4VdzupRRJMAbvm9tWFpQHd73SdPMN xmns:tfd $| = "$ 'http://www.sat.gob.mx/TimbreFiscalDigital"/> </cfdi:Complemento>
 [p2](#p2)

</cfdi:Comprobante>
 [p2](#p2)


## Página 3 <a id="p3"></a>

# Verificación de comprobantes fiscales digitales por internet

<table><tr><td>RFC del emisor</td><td>Nombre o razón social del RFC del receptor emisor</td><td></td><td>Nombre o razón social del receptor</td></tr><tr><td>IZS0711307Y4</td><td>INMOBILIARIA Z&#x27;CRUZ SILLER</td><td>SGO8501012H2</td><td>SECRETARIA DE GOBERNACION</td></tr><tr><td>Folio fiscal</td><td>Fecha de expedición</td><td>Fecha certificación SAT</td><td>PAC que certificó</td></tr><tr><td>D1E90A30-1566-DE45-8F6C- 3B63F3362312</td><td>2022-06-22T18:16:22</td><td>2022-06- 22T18:17:23</td><td>SCD110105654</td></tr><tr><td>Total del CFDL</td><td>Efecto del comprobante</td><td>Estado CFDI</td><td>Estatus de cancelación</td></tr><tr><td>$850.00</td><td>Ingreso</td><td>Vigente /</td><td>Cancelable sin aceptación</td></tr></table>
 [p3](#p3)

Imprimir
 [p3](#p3)

![](images/p3_57551e96efd2398852fe65b9458e8f6f7d407a94d9adabd76185ac496e8977ae.jpg)
 [p3](#p3)


## Página 4 <a id="p4"></a>

# Nota aclaratoria

Solicito su colaboración para que la factura con folio Z3191, emitida por la razón social INMOBILIARIA z'CRUz sILLER, S.A. DE C.V., sea tomada en cuenta pOr un monto de $\$ 425$ a favor de Bárbara Patricia Pacheco Contreras con número de empleado 642206.
 [p4](#p4)

![](images/p4_537562653302fbed19a0e79c5a2640f5ff6b0147240da2e68d75521c3b8a8f48.jpg)
 [p4](#p4)


## Página 5 <a id="p5"></a>

Factura: 378034043
 [p5](#p5)

Serie: ZAI   
I-INGRESO   
Uso CFDI: G03 - Gastos en general   
Régimen Fiscal:   
623 – Opcional para Grupos de Sociedades   
Folio Fiscal:   
d2a317b9-c07e-499c-a189-731a8442abfb   
Número del serie CSD del SAT: 00001000000414211380   
Número del serie CSD del emisor: 00001000000506505905
 [p5](#p5)

Fecha de emisión: 2022-06-21T13:06:24   
Fecha de certificación: 2022-06-21T13:06:29
 [p5](#p5)

Facturado a: SECRETARIA DE GOBERNACION Dirección: BUCARELI N. 99 C.P : 06600 Delegación/Municipio: CUAUHTEMOC Colonia: JUAREZ RFC: SGO8501012H2 Estado: CIUDAD DE MEXICO
 [p5](#p5)

<table><tr><td>Cantidad Clave ID</td><td colspan="4">Artículo Precio unitario Impuesto Importe</td></tr><tr><td>1.000000 EA 1.000000 EA</td><td>50131700 50202301</td><td>LECHE PAST LALA 100 PROT SEMIDESC 330 ML BONAFONT NATURAL 750ML TAPA PLANA</td><td>17.50 10.00</td><td>0.00 0.00</td><td>17.50 10.00</td></tr></table>
 [p5](#p5)

<table><tr><td>PUE-PAGO EN UNA SOLA EXHIBICIÓN</td><td>SUBTOTAL</td><td>27.50</td></tr><tr><td>Forma de Pago</td><td>TASA I.V.A 0%</td><td>0.00</td></tr><tr><td>28</td><td>TOTAL MXN</td><td>27.50</td></tr></table>
 [p5](#p5)

# Sello digital del CFDI

bc1htrcUj2XT17MC07016EKatdn $^ +$ GJd6XMfKCTeAIMrOsyEEoITNg7xUoOIVdnvXghERML/WWTKFiZHFMjLnAvqVfdKyC3KumRNn2v DIlhCCyleM6H14WA0x5FE+L59N9Wzgfss4vMUgCULzliUnyLyh/x065mpkbOwOHHiTKitoxUVSzx3jeCQ3Cyc9p9SmrtAwkmgHiY8jEs OD4z5XSTb3mrEHt0Mp3jB2U/pbzXImkJCIBGKdy4y2pytAyTdNEcHOyXeuExRc391US9ZKo8FNJARgAmLBtINwvW8vvomWC8Pbk z8E2exTv8DRYFc0/JrpajunJEccuxRvQA $\Longleftarrow =$
 [p5](#p5)

# Sello digital del SAT

ib6NyB6ZA4VzZLgG/8DbMApypDgV+HBUXWI2+xVD3wncTM7i/JVglXPLCDvgDxxznlM9OfYSNDVyUzBHItWMclqUU02eNUDu5kN8Wf HksBQxCXWwk4RdHRw1e/Ch3jdDAhSuxvePUAcVw9Kkeaf8WFggrKpz+uhjitmQeCCQftlFewjgNRYZSM+tP300gikWcpOH8Qq9s 4sYAbqJIgUyonMKsjQdL-zF3FwrPBd9B4IXyiwPInxbEKmU3005bHnlfb6fQCDN1Vige1ot7ey4UOyS9wkaSPZF $^ { \cdot } +$ yLW11YT5fNfvt7kg67rs AsqG35EhEbniYwcG $^ +$ SHL289GhlOfHPdA $\scriptstyle = =$
 [p5](#p5)

# Cadena Original

I11.1ld2a317b9-c07e-499c-a189-731a8442abfbl2022-06-   
21T13:06:29ISNF171020F3Albc1htrcUj2XT17MC07016EKatdn+GJd6XMfKCTeAIMrOsyEE0ITNq7xUoOIVdnvVXghERML/WWTKFiZHF MilLnAvgVfdKyC3KumRNn2vDIhCCyleM6H14WA0x5FE+L59N9Wzgfs4vMUgCULzliUnyLyh/xo65mpkbOwOHHiTKit0qxUVSzx3jeCQ 3Cyc9p9SmrtAwkmgHiY8jEsOD4z5XSTb3mrHt0Mp3jIB2U/fpbzXImkJCIBGKdy4yy2pzytAyTdNEcHOyXeuExRc391US9ZKo8FNJARgA mLBtlNwvW8vvomWC8Pbkz8E2exTv8DRYFc0/JrpajunJEccuxRvQA $= =$ 1000010000004142113801l
 [p5](#p5)

\*Este documento es una representación impresa de un CFDI.
 [p5](#p5)


## Página 6 <a id="p6"></a>

<?xml version $= " 1 . 0 "$ encoding="UTF-8"?>   
<cfdi:Comprobante xmlns:cartaporte2( $) = "$ http://www.sat.gob.mx/CartaPorte20" xmlns:implocal $= "$ http://www.sat.gob.mx/implocal"   
xmlns:pago $1 0 ^ { - \prime \prime }$ http:/www.sat.gob.mx/Pagos" xmlns:xsi="htp:/www.w3.org/2001/XMLSchema-instace" xmlns:cfd="http:/www.sat.gob.mx/cfd/3"   
xsi:schemaLocation $= ^ { 1 }$ http://www.sat.gob.mx/cfd/3 http://www.sat.gob.mx/sitio_internet/cfd/3/cfdv33.xsd" LugarExpedicion $= " 2 5 8 7 0 "$ MetodoPago="PUE"   
TipoDeComprobante $\mathbf { \mu } = " \mathbf { I } "$ Total $= " 2 7 . 5 0 "$ Moneda $= "$ MXN" SubTotal $= " 2 7 . 5 0 "$   
Certificad $\vartriangle { \ v { r } } = \ v {" }$ MIIGCDCCA/CgAWIBAgIUMDAwMDEwMDAwMDA1MDY1MDU5MDUwDQYJKoZIhvcNAQELBQAwggGEMSAwHgYDVQDDBBVVRPUkl   
NoCertificado $= "$ 00001000000506505905" FormaPagc $) = ^ { 1 1 } 2 8 ^ { \prime \prime }$   
Selld $| = ^ { \prime }$ 'be1htrUj2XT17MCO7016EKatdn+GJd6XMFKCTeAIMrOsyEEOITNq7xUoOIVdnvXghERML/WWTKFiZHFMjLnAvqVfdKyC3KumRNn2vDlhCCvleM6   
Fecha="2022-06-21T13:06:24" Folio="378034043" Serie $\varepsilon ^ { \prime \prime }$ ZAI" Version $= " 3 . 3 " >$ <cfdi:Emisor RegimenFiscal $= " 6 2 3 "$ Nombre $\mathrel { \mathop : } \mathbf { \Gamma }$ CADENA COMERCIAL OXXO, SA DE CV" Rfc $= "$ CCO8605231N4"/> <cfdi:Receptor Nombre $\mathrel { \mathop : } \mathbf { \Gamma }$ SECRETARIA DE GOBERNACION" Rf $\mathrel { \mathop : } \ "$ SGO8501012H2" UsoCFD $\scriptstyle 1 = " \mathbf { G } \mathbf { 0 } 3 " / >$ <cfdi:Conceptos> <efdi:Concepto Importe $= " 1 7 . 5 0 "$ ValorUnitaric $\mathbf { \varepsilon } = " 1 7 . 5 0 "$ Descripcion $= "$ LECHE PAST LALA 100 PROT SEMIDESC 330 ML" Unidad="EA" ClaveUnidad="EA" Cantidad="1.000000" ClaveProdServ="50131700"> <cfdi:Impuestos> <cfdi:Traslados> <cfdi:Traslado Importe $\mathbf { \mu } = " 0 . 0 0 "$ TasaOCuota $\mathbf { \tau } _ { 1 } = 1 1           0 . 0 0 0 0 0 0 0 ^ { \prime \prime }$ TipoFacto $\lceil \stackrel {  } { = } \ "$ Tasa" Impuestc $\cdot \mathbf { 0 0 } 2 ^ { \prime \prime }$ Bas $\mathrm { \ s = " } 1 7 . 5 0 \mathrm { " / > }$ </cfdi:Traslados> </cfdi:Impuestos> </cfdi:Concepto> <cfdi:Concepto Importe $\mathrel { \mathop : } \mathbf { \varLambda }$ '10.00" ValorUnitario $\mathbf { \mu } _ { 1 } \mathbf { 0 . 0 0 } ^ { \prime \prime }$ Descripcion $= "$ BONAFONT NATURAL 750ML TAPA PLANA" Unidad="EA" ClaveUnidad="EA" Cantidad="1.000000" ClaveProdServ="50202301"> <cfdi:Impuestos> <cfdi:Traslados> <cfdi:Traslado Importe $\mathbf { \mu } = " \mathbf { 0 . 0 0 " }$ TasaOCuota $\mathbf { \tau } ^ { = " } \mathbf { 0 . 0 0 0 0 0 0 0 ^ { \prime \prime } }$ TipoFacto ${ \bf \Phi } = { \bf \Phi } ^ { \mathsf { I } } $ Tasa" Impuesto $\mathbf { \mu } _ { 1 } \mathbf { = " } \mathbf { 0 0 2 " }$ Base $= " 1 0 . 0 0 " / >$ </cfdi:Traslados> </cfdi:Impuestos> </cfdi:Concepto.> </cfdi:Conceptos> <efdi:Impuestos TotallmpuestosTrasladados ${ \bf \bar { \tau } } ^ { \mathsf { m } } { \bf 0 . 0 0 } ^ { \mathsf { n } } >$ <cfdi:Traslados> <cfdi:Traslado Importe $\mathbf { \eta } _ { \mathrm { t } } = \ " \mathbf { 0 . 0 0 } "$ TasaOCuota="0.000000" TipoFactor="Tasa" Impuesto $\scriptstyle 1 = " 0 0 2 " / >$ </cfdi:Traslados> </cfdi:Impuestos> <cfdi:Complemento> <tfd:TimbreFiscalDigital xsi:schemaLocation="http://www.sat.gob.mx/TimbreFiscalDigital http://www.sat.gob.mx/sitio_internet/cfd/TimbreFiscalDigital/TimbreFiscalDigitalv11.xsd" Version="1.1" SelloSAT $= ^ { 1 }$ ib6NyB6ZA4VzLgG/8DbMApypDgV+HBUXWI2+xvD3wncTM7i/JVglXPLCDvgDxxznIM90fYSNDVyUzBHItWMcIqUU02eNUDu5kN8' NoCertificadoSAT="00001000000414211380" SelloCFD $| = "$ bc1htrcUj2XT17MCO7016EKatdn $^ +$ GJd6XMfKCTeAIMrOsyEE0ITNq7xUoOIVdnvXghERML/WWTKFiZHFMjLnAvqVfdKyC3KumR FechaTimbrad $\scriptstyle \ j = \prime$ 2022-06-21T13:06:29" RfcProvCertif="SNF171020F3A" UUID $\cdot = "$ d2a317b9-c07e-499c-a189-731a8442abfb" xmlns:tfd="http://www.sat.gob.mx/TimbreFiscalDigital"/> </cfdi:Complemento> <cfdi:Addenda> <ns:diverza xmlns:ns $\therefore = "$ http://www.diverza.com/ns/addenda/diverza/1" version $= " 1 . 1 " >$ <ns:generales tipoDocumento $= "$ Factura"/> <ns:clavesDescripcion c_UsoCFD $| = "$ Gastos en general" c_RegimenFiscal="Opcional para Grupos de Sociedades" c_MetodoPago="PAGO EN UNA SOLA EXHIBICION" c_TipoDeComprobante $\mathrel { \mathop : } \dim ^ { \prime }$ 'Ingreso"/> <ns:receptor> <ns:domicilioFiscalR codigoPostal $\mathbf { \mu } = " 0 6 6 0 0 "$ pais $= ^ { 1 }$ 'México" estado $\scriptstyle { \mathfrak { p } } ^ { n }$ CIUDAD DE MEXICO" municipio="CUAUHTEMOC" ciudad="CUAUHTEMOC" colonia $= "$ JUAREZ" numero="99" calle $\varepsilon ^ { \prime \prime }$ BUCARELI"/> </ns:receptor> </cfdi:Addenda> </ns:diverza> BA   
</cfdi:Comprobante>
 [p6](#p6)


## Página 7 <a id="p7"></a>

# Verificación de comprobantes fiscales digitales por internet

<table><tr><td>RFC del emisor</td><td>Nombre o razón social del emisor</td><td></td><td>RFC del receptor Nombre o razón social del receptor</td></tr><tr><td>CCO8605231N4</td><td>CADENA COMERCIAL OXXO, SGO8501012H2 SA DE CV</td><td></td><td>SECRETARIA DE GOBERNACION</td></tr><tr><td>Folio fiscal</td><td>Fecha de expedición</td><td>Fecha certificación SAT</td><td>PAC que certificó</td></tr><tr><td>D2A317B9-C07E-499C-A189- 731A8442ABFB</td><td>2022-06-21T13:06:24</td><td>2022-06- 21T13:06:29</td><td>SNF171020F3A</td></tr><tr><td>Total del CFDI</td><td>Efecto del comprobante</td><td>Estado CFDI</td><td>Estatus de cancelación</td></tr><tr><td>$27.50</td><td>Ingreso</td><td>Vigente</td><td>Cancelable sin aceptación</td></tr></table>
 [p7](#p7)

![](images/p7_1d9370c5943028d8f38888839f3831f4de926fe69c3733d74986dbb1e7c6f65b.jpg)
 [p7](#p7)


## Página 8 <a id="p8"></a>

Cadena Conercial 0xxo, S.A. de C.V.(CC0-860523-1N4) SANTA MARIA LOU   
Edison Nte. Hunero 1235 Colonia talleres Honterrey. Nuev o Leon C.P. 64480 Reginen de Opcional para_Grupos de _Sociedades 18/06/202? 10.00   
CRTELU7812220 3 17.50   
BONAFONT NATURAL 750 Total: \$ 27.50   
LPAST LALA 100 PROT 19A INC181D0: § 0.00   
Fol_0ta:1167727   
ID=102A150PUF3   
VEINTISIETE PES0S 50/100 H.N.   
Pago Electrónico: 27.50 BBUA BANCOMER Enisur: BANCOHER 4000:19 VENCE / AFILIACION TARETA CEBITO 21.50 AlT: 851958 10101-, \$ 001 GULORIZADO MEDTANIE FIRIA–ELECIRORECA ARQC: AR0C: 8DCF50306344808B AID: AID: A0000000031010 Pago: \$ 27.50 _Canbio: \$ 0.00 \*\*\*\*\*\* OXK0 PREMIA \*\*\*\*\*\* ¿BOTANAGRATIS? Registrate a UXX0 PREmA. acumula puntos en tus visitas y caniéalos por PRoBucTos GRAlIS. Descarga la app fi uxxo o pide tu tarieta oxx0 PREhlA en tienda. HUCHAS GRACIAS POR SU COMPRA PAGO EN UNA SOLA EXITBICTON LUGAR DE EXPEDICION:CASTAVOS: COAMUITA CARRETERA 57 A2502 CASTAVOS, CASTAVOS COAMULIA C.P.25870 enail:atencionaclientes0onxo.con Feléfono sin costo 81 83 20 20 20
 [p8](#p8)


## Página 9 <a id="p9"></a>

# Factura: 378035347

Serie: NLA   
I-INGRESO   
Uso CFDI: G03 - Gastos en general   
Régimen Fiscal:   
623 – Opcional para Grupos de Sociedades   
Folio Fiscal:   
4bdc7890-364c-43b9-8daa-956da92fc270   
Número del serie CSD del SAT: 00001000000414211380   
Número del serie CSD del emisor: 00001000000506505905
 [p9](#p9)

Fecha de emisión: 2022-06-21T13:14:05   
Fecha de certificación: 2022-06-21T13:14:07
 [p9](#p9)

Facturado a: SECRETARIA DE GOBERNACION   
Dirección: BUCARELI N. 99   
Delegación/Municipio: CUAUHTEMOC   
RFC: SGO8501012H2   
C.P : 06600   
Colonia: JUAREZ   
Estado: CIUDAD DE MEXICO
 [p9](#p9)

<table><tr><td>Cantidad</td><td>Clave ID</td><td>Artículo</td><td>Precio unitario Impuesto</td><td>4.89</td><td>Importe</td></tr><tr><td>2.000000 EA 1.000000 EA 1.000000 EA</td><td>90101504 50181900 50201708</td><td>BURRITO DE FRIJOLES DONA DECORADA 1 PZA 12OZ AMER REG PGS OSMO</td><td>30.56 15.00 18.98</td><td>0.00 1.52</td><td>61.11 15.00 18.98</td></tr></table>
 [p9](#p9)

<table><tr><td>PUE-PAGO EN UNA SOLA EXHIBICIÓN</td><td>SUBTOTAL</td><td>95.09</td></tr><tr><td>Forma de Pago</td><td>TASA I.V.A 0%</td><td>0.00</td></tr><tr><td>28</td><td>TASA I.V.A 8%</td><td>6.41</td></tr><tr><td></td><td>TOTAL MXN</td><td>101.50</td></tr></table>
 [p9](#p9)

# Sello digital del CFDI

hz2bPh2dpd8miQLSpbZlunOSOD4cwluLIsAgggGY6G4VpcTAsngWy+TABXJBXHafYygWsC9xcKUmMOJ1 hbJQed8dZlyQgWXyo03V Ne58f80iglfbmsnE/6aBDz8TcBvAQriYD6JBnCd51sOTRee45rg8TIPIG4A8CNWC68v3k1fNEA2ahKOJxnyilq TLI99IRpHIOkVb8lfT $+ \mathrm { b } \mathsf { Y }$ 1VIAUn5iMI/uzZY5Euw6N6QVilPDtYy $+$ 4ZMUNfSxWCmh5OUGMTQPINtr+GR3iqVzFV04VZfqzlbuCS2kER3gFF8iZXt6Ov1E1rUljVhoh H2SS79vqQaMZXknQGRCUhm6V3zA $\mathbf { = } =$
 [p9](#p9)

# Sello digital del SAT

IXI+ZgD+4+MJ2Lx2a4Bwyn $^ +$ gt8LBAIEyWr41Vfn72ofHzvAvalufsa0k9lhhUByVmxsQ2WzX5mzogju60jlDrNMQKKH2JIFmYgCuvzCazIn g8oFZOK7JtZoTH8fxXODMv3NvtG3qBItxn $^ +$ 119IDDr+JJUdxijq/xbOJBJs5/0B2UWeaJlRI8ffGLTU67E+SD2F6ymEazehWEDW0TZWx3 YDdg8hv/6ieS1cTLXYYQ9SYoJhEuGYVR0OtL2meNPSKhHDmDcTvaBYZ/VrC3QfuZLN8/kgPF4rkoRv+WdTBptNeFKIpFwd9QtzZONM7 GH77GQjzZoCyxMcDje7jbzKLpmQ $\mathrel { = } =$
 [p9](#p9)

# Cadena Original

I11.114bdc7890-364c-43b9-8daa-956da92fc27012022-06-   
21T13:14:07ISNF171020F3AlhZ2bPh2dpd8miQLSpbZIunOS0D4cwl6uLIsAggGY6G4VpcTAsngWy+TABXJBXHafYygWsC9xcKUmM OJ1hblJQed8dZlyQgWXv03VNe58f80glfbmsnE/6aBDz8TcBvAQrjY D6JBnCd51sOTRee45rg8TIPIG4A8CNWC68v3k1fNEA2ahKOJx nyilqTLI9IRpHIOKVb8lf/T+bY1VIAUn5iMI/uzZY5Euw6N6QVIPDtYy+4ZMUNfSxWCmh5OUGMTQPINtr+GR3iqVzFV04VZfqzlbuCS2k ER3gFF8iZXt6Ov1E1rUIjVhohH2SS79vqQaMZXknQGRCUhm6V3zA $= =$ 00001000000414211380ll
 [p9](#p9)

'Este documento es una representación impresa de un CFDI.
 [p9](#p9)


## Página 10 <a id="p10"></a>

${ < } ? \mathrm { x n } 1$ version="1.0" encoding="UTF- $8 " ? >$   
<cfdi:Comprobante xmlns:cartaporte2 $\vartriangle { \ v { r } } = \ v { r }$ http:/www.sat.gob.mx/CartaPorte20" xmlns:implocal="htp://www.sat.gob.mx/implocal"   
xmns:pago $0 { = } "$ htt:/www.satgob.mx/Pagos" xmlns:xsi="htp:/ww.w3.org/2001/xMLSchema-instance" xmls:cfdi="http:/www.sat.gob.mx/efd/3"   
xsi:schemaLocation $= ^ { 1 }$ 'http://ww.sat.gob.mx/cfd/3 htp:/www.sat.gob.mx/sitio_internet/cfd/3/cfdv33.xsd" LugarExpedicion="26170" MetodoPag $\scriptstyle 1 = 1$ PUE"   
TipoDeComprobante="I" Total $\mathbf { \Lambda } = " 1 0 1 . 5 0 "$ Moneda $\varepsilon ^ { n }$ MXN" SubTotal $\mathbf { \left| = " 9 5 . 0 9 " \right. }$   
Certificado="MIGCDCCA/CgAwIBAglUMDAwMDEwMDAwMDA1MDY1MDU5MDUwDQYJKoZIhveNAQELBQAwggGEMSAwHgYDVQDBBVVRPUkI   
NoCertificado="00001000000506505905" FormaPago="28"   
Sell $\bullet ^ { \bullet }$ hZ2bPh2dpd8miQLSpbZlunOS0D4cwluLIsggqGY6G4VpcTAsngWy+TABXJBXHafYygWsC9xcKUmMOJ1hblJQed8dZIyQqWXv03VNe580iglfbmsn   
Fecha $= ^ { 1 }$ '2022-06-21T13:14:05" Folio $= ^ { \prime }$ 378035347" Serie="NLA" Version $= " 3 . 3 " >$ <efdi:Emisor RegimenFiscal="623" Nombre $: = "$ CADENA COMERCIAL OXXO, SA DE CV" Rfc="CCO8605231N4"/> <efdi:Receptor Nombre $\mathrel { \mathop : } \mathbf { \Gamma }$ 'SECRETARIA DE GOBERNACION" Rf $! = !$ 'SGO8501012H2" UsoCFDI $- \mathbf { ^ { 1 1 } G 0 3 ^ { 1 1 } } / >$ <cfdi:Conceptos> <cfdi:Concepto Importe="61.11" ValorUnitario $= " 3 0 . 5 6 "$ Descripcion $\mathbf { \lambda } = ^ { 1 1 }$ BURRITO DE FRIJOLES" Unidad="EA" ClaveUnidad="EA" Cantidad="2.000000" ClaveProdServ="90101504"> <cfdi:Impuestos> <cfdi:Traslados> <cfdi:Traslado Importe $= " 4 . 8 9 "$ TasaOCuota="0.080000" TipoFactor="Tasa" Impuesto="002" Base $= " 6 1 . 1 1 " / >$ </cfdi:Traslados> </cfdi:1mpuestos> </cfdi:Concepto.> <cfdi:Concepto Importe $= ^ { 1 }$ '15.00" ValorUnitaric $\mathbf { \varepsilon } = " 1 5 . 0 0 "$ Descripcion $\bullet ^ { * }$ DONA DECORADA 1 PZA" Unidad="EA" ClaveUnidad="EA" Cantidad="1.000000" ClaveProdServ="50181900"> <cfdi:Impuestos> <cfdi:Traslados> <cfdi:Traslado Importe $\mathbf { \mu } ^ { = " } \mathbf { 0 . 0 0 " }$ TasaOCuota="0.000000" TipoFactor="Tasa" Impuesto $\stackrel { \_ } { }$ '002" Base $= " 1 5 . 0 0 " / >$ </efdi: Traslados> </cfdi:Impuestos> </cfdi:Concepto> <cfdi:Concepto Importe $= " 1 8 . 9 8 "$ ValorUnitario $= " 1 8 . 9 8 "$ Descripcion $\cdot = "$ 120Z AMER REG PGS OSMO " Unidad="EA" ClaveUnidad="EA" Cantidad="1.000000" ClaveProdServ $v = "$ 50201708"> <cfdi:Impuestos> <cfdi:Traslados> <cfdi:Traslado Importe="1.52" TasaOCuota="0.080000" TipoFactor="Tasa" Impuesto $= " { \bf 0 0 2 ^ { \prime \prime } }$ Base $= ^ { 1 1 } 1 8 . 9 8 ^ { 1 1 } / >$ cY </cfdi:Traslados> </cfdi:Impuestos> </cfdi:Concepto> </cfdi:Conceptos> <cfdi:Impuestos TotalImpuestosTrasladados $= " 6 . 4 1 " >$ <cfdi:Traslados> <cfdi: Traslado Importe $\mathbf { \mu } _ { : } = " 0 . 0 0 "$ TasaOCuota $\mathbf { \tau } = " 0 . 0 0 0 0 0 0 0 "$ TipoFactor="Tasa" Impuesto $\bf \Pi ^ { - 1 1 } 0 0 2 ^ { 1 1 } / \lambda >$ <cfdi:Traslado Importe="6.41" TasaOCuota $\mathbf { \tau } = \mathbf { \ " { 0 . 0 8 0 0 0 0 0 } " }$ TipoFactor="Tasa" Impuesto $= " 0 0 2 " / >$ </cfdi:Traslados> </cfdi:1mpuestos> <cfdi:Complemento> <tfd:TimbreFiscalDigital xsi:schemaLocation $= "$ http:/www.sat.gob.mx/TimbreFiscalDigital http://www.sat.gob.mx/sitio_internet/cfd/TimbreFiscalDigital/TimbreFiscalDigitalv11.xsd" Version="1.1" SelloSAT="IXI1+ZgD+4+MJ2Lx2a4Bwyn+g8LBAEyWr41Vfn72ofHzvAvalfsa0k9hhUByVmxQ2WzX5mzogju60jIDrNMQKKH2JFm YgCuvzCa: NoCertificadoSAT $= ^ { \prime }$ 00001000000414211380" SelloCFD="hZ2bPh2dd8miQLSpbZlunOS0D4cwl6uLIsAggqGY6G4VpcTAsngWy+TABXJBXHafYygWsSC9xcKUmMOJ1hblJQed8dZlyQqWXv03 FechaTimbrado $\varepsilon ^ { \prime }$ 2022-06-21T13:14:07" RfcProvCertif="SNF171020F3A" UUID $\lvert = ^ { \dag }$ 4bdc7890-364c-43b9-8daa-956da92fc270" xmlns:tfd="http://www.sat.gob.mx/TimbreFiscalDigital" $/ >$ </cfdi:Complemento> <cfdi:Addenda> <ns:diverza xmlns:ns="http://www.diverza.com/ns/addenda/diverza/1" version $= " 1 . 1 " >$ <ns:generales tipoDocumento $| = "$ Factura"/> <ns:clavesDescripcion c_UsoCFD $= "$ Gastos en general" c_RegimenFiscal $= "$ Opcional para Grupos de Sociedades" c_MetodoPagc $\bullet ^ { \prime \prime }$ PAGO EN UNA SOLA EXHIBICIōN" c_TipoDeComprobante="Ingreso"/> <ns:receptor> <ns:domicilioFiscalR codigoPostal- $\mathbf { \bar { \mathbf { \Lambda } } } ^ { \mathrm { 1 1 } } \mathbf { 0 6 6 0 0 ^ { \mathrm { 1 1 } } }$ pais $\mathbf { \lambda } = \mathbf { \lambda } ^ { \prime }$ 'México" estadc $\upsilon ^ { = " }$ CIUDAD DE MEXICO" municipio="CUAUHTEMOC" ciudad="CUAUHTEMOC" colonia $| = "$ JUAREZ" numero="99" call $\varepsilon ^ { \prime \prime }$ BUCARELI"/> </ns:receptor> </cfdi:Addenda> </ns:diverza> F   
</cfdi:Comprobante>
 [p10](#p10)


## Página 11 <a id="p11"></a>

# Verificación de comprobantes fiscales digitales por internet

<table><tr><td>RFC del emisor</td><td>Nombre o razón social del emisor</td><td></td><td>RFC del receptor Nombre o razón social del receptor</td></tr><tr><td>CC08605231N4</td><td>CADENA COMERCIAL OXXO, SGO8501012H2 SA DE CV</td><td></td><td>SECRETARIA DE GOBERNACION</td></tr><tr><td>Folio fiscal</td><td>Fecha de expedición</td><td>Fecha certificación SAT</td><td>PAC que certificó</td></tr><tr><td>4BDC7890-364C-43B9-8DAA- 956DA92FC270</td><td>2022-06-21T13:14:05</td><td>2022-06- 21T13:14:07</td><td>SNF171020F3A</td></tr><tr><td>Total del CFDI</td><td>Efecto del comprobante</td><td>Estado CFDI</td><td>Estatus de cancelación</td></tr><tr><td>$101.50</td><td>Ingreso</td><td>Vigente</td><td>Cancelable sin aceptación</td></tr></table>
 [p11](#p11)

![](images/p11_8c6ee69d5d620800047e31502984607ae4302e921b94e8435c519b76617c1eff.jpg)
 [p11](#p11)


## Página 12 <a id="p12"></a>

Cadena Conercia) 0xxD, S.A_ de C.0. (C0-850523-104) WILLIE POS Edison Nte. Nunero 1235 Colonia talleres lionterrey. Huev   
0 Lson C.P. 64480 Reginen de Opcional para Grupos de Soctedades   
12PR A9ER REG OSHO 1706/2022 09:20.50 BORRITO DE FRIJOLES 66.00 DOHA DECORADA 1 PZA 15.00 Fol_ 0ta:669033 fotal:  101.50   
10 10M A50DF41 109 INCLUIDO: \$ 6.41 CIENTO UNO PESOS 50/100 H.N. Pa  Elactrónico: 101.50 BBOABANCOMER EniSOr: BANCOHER VENTA AF ILIACION 4158171 TA6JETA \*\*\*\*\*\*\*\*\*661 VENCE 1 DEBITO AUT: 705298 TOIAL M.1. \$ 101.50   
001 AUTORIZADO NEOIANTE FIRHA ELECTRONICA ARUC: AR0C: 9931220206459889 AI0: A10: A0006000031010 Pago: \$ 101.50 Canbio. \$ 0.00 OXXO PR ¿COTANAGRAT IS? Registrata a UXXo PREMIn. acunule puntos en tus visitas y Caniéalos POr PRODUCTOS GRATIS. Descarga la app Hi 0xx0 o pide tu tar jeto OXx0 PREnIA en tienda. PAGO EN UNA SOLA EXHIDICION RUCHAS URACIAS POR SO CONPRA LOGAR DE EXPEDIC 1ON:NA0A. CORHUILA CARRETERA 57 KN 238 HAVA, NAVA CORHUILA C.P.26170 Teléfono sin costo 81 83 20 20 20 Telétono sin costo ai 83 20 20 20
 [p12](#p12)


## Página 13 <a id="p13"></a>

Cliente SECRETARIA DE GOBERNACION   
BUCARELI 99   
JUAREZ, DEL. CUAUHTEMOC   
CIUDAD DE MEXICO, MEX CP: 06600   
RFC: SGO8501012H2   
Domicilio fiscal: 06600   
Régimen fiscal: 603/Personas Morales con Fines no Lucrativos   
Orden de compra Condiciones Vendedor Vía de embarque CONTADO Artículo Nombre U.med.  Unidades Precio Descto. Importe   
C1 SERVICIOS DE RESTAURANTE SERVICIOS 1 687.931 687.93 90101501/Restaurantes E48/Unidad de servicio
 [p13](#p13)

# Cadena original del complemento de certificación digital del SAT:

p7Ag==|001000002000436|
 [p13](#p13)

Sello digital del CFDI:
 [p13](#p13)

8TtkyJEPKe7HImkdhCVgRdAGBopyZHY4/AVTc79lpiSOhkxsRYhCofsD7QeSit+jldyCACiSr3VE/5A/u9yd5qTjTpybzLhEXNCzuGEbi8ZfAg $= =$ -
 [p13](#p13)

# Sello digital del SAT:

1cJr+ZarqduqAXkpzykFPiq+gd1987TTI+ELGutv5sDDobN57sqgdLnTQIh8e/LSWRDCKbngejbk3xuW4DAUZguGhYmHXedCTNIkY1Sk+hObRtHH94sQaYOXPCl $= =$
 [p13](#p13)

![](images/p13_867cb0bd45fce28ee38be74d7a8afdd508ec0cc31ad36c1130afef6475bbe6a6.jpg)
 [p13](#p13)

<table><tr><td>□ (Setecientos noventa y ocho pesos 00/100 m.n.) Método de pago: PUE/Pago en una sola exhibición Forma de pago: 01/Efectivo aF. Uso del CFDI: G03/Gastos en general</td><td>Subtotal 002|IVA 16%</td><td>687.93 110.07</td></tr><tr><td colspan="2">Este documento es una representación impresa de un CFDI. Folio del SAT: C25B1F04-2D2C-164C-808B-90689EFD1883 Fecha de ce tiición 7/un/202 23:14:39 Certicad el emisor 0004130898 Certificado dl SAT: 00000046 Régimen fiscal del emisor: 612/Personas Físicas con Actividades Empresariales y Profesionales Lugar de expedición: 26788</td><td>798.00 CFDI 4.0/Ingreso</td></tr></table>
 [p13](#p13)


## Página 14 <a id="p14"></a>

$\mathrm { < } ? \mathrm { x m } !$ version $= " 1 . 0 "$ encoding $= ^ { 1 1 }$ UTF- $8 " ? >$   
<efdi:Comprobante LugarExpedicion $= ^ { \prime }$ '26788" MetodoPago $\varepsilon ^ { \prime \prime }$ PUE" Exportacion $\mathbf { \mu } ^ { = " } \mathbf { 0 } 1 "$ TipoDeComprobante="I" Total $\mathbf { \tau } = " 9 9 8 . 0 0 "$ Moneda $\cdot = "$ MXN" SubTotal="687.93"   
CondicionesDePago $\cdot = "$ CONTADO"   
Cerificado="MIIGIDCCBAigAWIBAgIUMDAwMDEwMDAwMDA0MTMwNj4OTgwDQYJKoZIhveNAQELBQAwggGyMTgwNgYDVQDDC9BLkMuIGRI   
NoCertificado="00001000000413060898" FormaPagc $\scriptstyle 1 0 1$ =   
Sellα $\varepsilon ^ { \prime \prime }$ uBmN+05Nf0DevQ3GEE5j7O4CJ2QxOr8jR5x/zpsSH+SM/uljtbXoRhmVp1xZuYOm1gqQ9T0MBL6yobrgl8qcLT7GyvfMupWWRHozT8qIBquXXPqCd   
Fecha="2022-06-17T23:13:16" Folio $= " 1 9 5 7 4 "$ Serie-"F" Version $= " 4 . 0 "$ xmlns:cfdi="http://www.sat.gob.mx/cfd/4" xsi:schemaLocation="http://www.sat.gob.mx/cfd/4   
http://www.sat.gob.mx/sitio_internet/cfd/4/cfdv40.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchena-instance"> <efdi:Emisor RegimenFiscal $= " 6 1 2 "$ Nombe $\mathrel { \mathop : } \stackrel { \Uparrow }$ MAYRA DENNIS HERRERA SANMIGUEL" Rf $= ^ { \prime }$ 'HESM681104F7A"/> <cfdi:Receptor Nombre $\models ^ { \prime }$ 'SECRETARIA DE GOBERNACION" Rf $\mathrel { \mathop : } = \mathrel { \mathop : }$ SGO8501012H2" UsoCFD $\mathbf { \bar { \mathbf { G } } 0 3 " }$ RegimenFiscalReceptor="603" DomicilioFiscalReceptor- $\mathbf { \tau } ^ { \mathrm { w } } \mathbf { 0 } 6 6 \mathbf { 0 0 } ^ { \mathrm { * } \mathrm { \prime } } / >$ <cfdi:Conceptos> <cfdi:Concepto ObjetoImp $\mathbf { \mu } _ { 1 } \mathbf { = } " \mathbf { 0 } 2 \mathbf { " }$ Importe $= " 6 8 7 . 9 3 "$ ValorUnitaric $\mathbf { \tau } _ { 1 1 } = 1 1 6 8 7 . 9 3$ 1" Descripcion $= ^ { n }$ SERVICIOS DE RESTAURANTE" Unidad="SERVICIOS" ClaveUnidad="E48" Cantidad="1" Noldentificacion="C1" ClaveProdServ="90101501"> <cfdi:Impuestos> <cfdi:Traslados> <cfdi:Traslado Importe="110.0688" TasaOCuota="0.16000" TipoFactor="Tasa" Impuesto="002" Base="687.93"/> </cfdi:Traslados> </cfdi:Impuestos> </cfdi:Concepto> </cfdi:Conceptos> <efdi:Impuestos TotalImpuestosTrasladados $\mathbf { \tau } ^ { = " } 1 1 0 . 0 7 " >$ <cfdi:Traslados> <cfdi:Traslado Importe $= " 1 1 0 . 0 7 "$ TasaOCuota="0.160000" TipoFactor="Tasa" Impuestc $\mathbf { \mu } _ { 1 } \mathbf { = } " 0 0 2 ^ { \prime \prime }$ Base="687.93"/> </cfdi:Traslados> </cfdi:Impuestos> <cfdi:Complemento> <tfd:TimbreFiscalDigital Version="1.1" xsi:schemaLocatior $\scriptstyle 1 = "$ http://www.sat.gob.mx/TimbreFiscalDigital http://www.sat.gob.mx/sitio_internet/cfd/TimbreFiscalDigital/TimbreFiscalDigitalv11.xsd" UUID $\ v { x } = \ v { r }$ 'C25B1F04-2D2C-164C-808B-90689EFD1883" FechaTimbrado="2022-06-17T23:14:39" RfcProvCertif="SCD110105654" SelloCFD="uBmN+05Nf0DevQ3GEE5j7O4CJ2QxOr8jR5x/VzpsH+SM/uljtbXoRhmVp1xZuYOm1gqQ9T0MBL6yobrgl8qcLT7GyvfMupWRHo. NoCertificadoSAT="00001000000502000436" SelloSAT $\underline { { \underline { { \mathbf { \Pi } } } } } = \mathbf { \mathfrak { n } }$ KCV8bEoDqufCkfcQYPvzyEF4UX3YnHQaBMoJfSnhTUxy/31zZUso8ZO+KaevJv+uCUgIQnLIsDDYAvGQRm4vkPrNVHtP+wVg4v xmlns:tfd="http:/www.sat.gob.mx/TimbreFiscalDigital"/> </cfdi:Complemento>
 [p14](#p14)

</cfdi:Comprobante>
 [p14](#p14)


## Página 15 <a id="p15"></a>

# Verificación de comprobantes fiscales digitales por internet

<table><tr><td>RFC del emisor</td><td>Nombre o razón social del emisor</td><td></td><td>RFC del receptor Nombre o razón social del receptor</td></tr><tr><td>HESM681104F7A</td><td>MAYRA DENNIS HERRERA SANMIGUEL</td><td>SGO8501012H2</td><td>SECRETARIA DE GOBERNACION</td></tr><tr><td>Folio fiscal</td><td>Fecha de expedición</td><td>Fecha certificación SAT</td><td>PAC que certificó</td></tr><tr><td>C25B1F04-2D2C-164C-808B- 90689EFD1883</td><td>2022-06-17T23:13:16</td><td>2022-06- 17T23:14:39</td><td>SCD110105654</td></tr><tr><td>Total del CFDI</td><td>Efecto del comprobante</td><td>Estado CFDI</td><td>Estatus de cancelación</td></tr><tr><td>$798.00</td><td>Ingreso</td><td>Vigente</td><td>Cancelable sin aceptación</td></tr></table>
 [p15](#p15)

Imprimir
 [p15](#p15)

![](images/p15_e8cfcf510176b962cc5756e6b54ec27833783b5afd48b22ddda2a6b28658f13b.jpg)
 [p15](#p15)


## Página 16 <a id="p16"></a>

# 4E70M47

Pase de Abordar
 [p16](#p16)

Pacheco Contreras / Barbara Patricia Ms ORIGEN DESTINO 06:20 MEXPDS 09:05 17 Jun 2022 17 Jun 2022 Terminal 2 Mexico City Benito Juarez I Piedras Negras Internationa   
VUELO Asiento Hora de Abordaje ZONA PUERTA   
VW220 3A 05:45 A
 [p16](#p16)

# INFORMACIÓN DEL VIAJE

![](images/p16_1bbc55d12bfe55bdc18f281e8bc8b4591253c8024d5693a915681e1176d86c9c.jpg)
 [p16](#p16)

Información del Pase de Abordar Deberá presentar su pase de abordar digital o impreso en conjunto con una identificación oficial.
 [p16](#p16)

![](images/p16_3becf31698fd483ef2786fffa0c03249e1a9d560e65a1303cb5dcf9bac1b337f.jpg)
 [p16](#p16)

# Política de equipaje - Franquicia

Su equipaje para documentar puede estar sujeto a cargos adicionales. Revisa tarifas, términos y condiciones de equipajes en aeromar.mx
 [p16](#p16)

# Viajero Frecuente None

![](images/p16_414d9f58905560053d8f05b42bc3c3abf7a039e614dc91e6109344a77195c30d.jpg)
 [p16](#p16)

# Documentos del viaje

# Equipaje de mano permitido

Su equipaje de mano puede estar sujeto a cargos adicionales. Revisa tarifas, términos y condiciones de equipajes en aeromar.mx
 [p16](#p16)

![](images/p16_70a321c05407cb98c64bd631369170fdec474019f636f66e6f69be1fee7532b7.jpg)
 [p16](#p16)

Por favor tenga en cuenta que el pasajero es responsable de la validez de su pasaporte así como de los otros documentos legales de viaje para todos su tramos
 [p16](#p16)

Clase de viaje
 [p16](#p16)

Referencia de la Reservación 28ZCA6
 [p16](#p16)

①
 [p16](#p16)

# Otra información

Información de Contacto: Whatsapp: $+ 5 2$ 55 5133 1111 Reservaciones: 55 5133 1111 Servicios al Cliente: 55 5133 1111 Correo Electrónico: sac $@$ aeromar.com.mx Vía Web: www.aeromar.mx/contacto
 [p16](#p16)

Boleto   
ETKT   
942671008931301
 [p16](#p16)

# INFORMACIÓN ADICIONAL

L
 [p16](#p16)

# Nota

Los pasajeros que realicen documentación vía WEB CHECK IN o pre-documentados en mostrador de aeropuertos de nuestra red de rutas deberán presentarse en sala de última espera 45 minutos antes de la salida del vuelo para rutas nacionales o 50 minutos antes de la salida del vuelo para rutas internacionales.
 [p16](#p16)

![](images/p16_0ff65640ed04c416a1d16b5cc88883e99dee84c61151cb479fcb1f7f598ef589.jpg)
 [p16](#p16)

# Salidas

Gracias por volar con Aeromar. ¡Esperamos que tenga un excelente vuelo!
 [p16](#p16)

![](images/p16_466afb6fad23b2650d794ae09379241bba387a3e9789e812f888abe59ff79e04.jpg)
 [p16](#p16)

# Tiempo límite Eq. Documentado

Si tiene equipaje para documentar, por favor acuda al mostrador de Aeromar para asistencia personal.   
Le recomendamos presentarse en nuestros mostradores de los aeropuertos 90 minutos antes de la salida de su vuelo, ya que la documentación del mismo se cierra 45 minutos antes de la hora de salida.
 [p16](#p16)

![](images/p16_fb08beec76e1b75d36d274ceb6c7e69427e57c2a02217ef737d330dc3d99aeef.jpg)
 [p16](#p16)

# Abordaje

Favor de presentarse en la sala de abordar a más tardar 45 minutos antes de la hora programada de salida de su vuelo.
 [p16](#p16)


## Página 17 <a id="p17"></a>

# Barbara Patricia Ms Pacheco Contreras

# MTY MEX

<table><tr><td colspan="2">VIL</td></tr><tr><td colspan="2">Monterrey a Ciudad de México SQXPLG 1396710089314 Y</td></tr><tr><td colspan="2"></td></tr><tr><td>VUELO VUELO AM 0927</td><td>SALA SALA TBD</td></tr><tr><td>18 jun., 2022 SALIDA SALIDA</td><td>Zona / Zone 4</td></tr><tr><td>12:59</td><td>ASIENTO ASIENTO 23E</td></tr><tr><td>Abordaje 12:29 Abordaje 12:29</td><td>Cabina Turista, Asiento Cabina Turista, Asiento</td></tr></table>
 [p17](#p17)
